# Alquiler de vehículos · Caso práctico de POO

Proyecto Java sencillo, **sin Maven ni Gradle**, que acompaña al capítulo 7 del curso
[POO · Programación Orientada a Objetos](https://rlrprofe.github.io/poo/).
Modela una empresa de alquiler de vehículos y reúne todos los conceptos del curso: clases,
objetos, encapsulación, herencia, polimorfismo (clases abstractas e interfaces) y relaciones
entre objetos (asociación, agregación y composición).

## Estructura del proyecto

```text
alquiler-vehiculos/
├── README.md
├── .gitignore
└── src/
    ├── modelo/                 ← clases que modelan los datos del negocio
    │   ├── Alquilable.java       interfaz: lo que se puede alquilar
    │   ├── Vehiculo.java         clase abstracta: base de coches y camiones
    │   ├── Coche.java            subclase de Vehiculo
    │   ├── Camion.java           subclase de Vehiculo (velocidad máxima 90 km/h)
    │   ├── PlazaGaraje.java      otro Alquilable que no es un vehículo
    │   ├── Conductor.java        quien alquila
    │   ├── Flota.java            agrupa vehículos (agregación)
    │   ├── Alquiler.java         vehículo + conductor + días + extras
    │   └── Extra.java            GPS, silla infantil… (composición)
    └── app/                    ← programa que usa el modelo
        └── Main.java             punto de entrada (método main)
```

Los **paquetes** (`modelo`, `app`) son carpetas dentro de `src/` y cada archivo empieza con su
declaración `package`. Separar el modelo del programa que lo usa es una buena costumbre:
las clases de `modelo` no saben nada de `app` y podrían reutilizarse en otra aplicación.
`Main` necesita escribir `import modelo.Flota;`, etc., para poder usar las clases de otro paquete.

## Diagrama de clases

```mermaid
classDiagram
    class Alquilable {
        <<interface>>
        +costeAlquiler(int dias) double
    }
    class Vehiculo {
        <<abstract>>
    }
    Alquilable <|.. Vehiculo
    Alquilable <|.. PlazaGaraje
    Vehiculo <|-- Coche
    Vehiculo <|-- Camion
    Flota "1" o-- "0..*" Vehiculo
    Alquiler "*" --> "1" Vehiculo
    Alquiler "*" --> "1" Conductor
    Alquiler "1" *-- "0..*" Extra
```

## Compilar y ejecutar

Necesitas un JDK 17 o superior (`javac -version`). Desde la carpeta `alquiler-vehiculos`:

```text
javac -encoding UTF-8 -d out src/modelo/*.java src/app/*.java
java -cp out app.Main
```

- `-d out` indica dónde dejar los `.class` (se crea la carpeta `out/` con una subcarpeta por paquete).
- `-cp out` (*classpath*) le dice a `java` dónde buscar las clases compiladas.
- Se ejecuta el nombre **completo** de la clase: `app.Main`, no solo `Main`.

Si el comodín `*.java` da problemas en tu terminal, esta variante compila `Main` y todas las
clases que necesita:

```text
javac -encoding UTF-8 -d out -sourcepath src src/app/Main.java
```

La salida esperada empieza así:

```text
=== Flota ===
5671BCD - Ford Focus - rojo
4410KLM - Seat Ibiza - azul
1234XYZ - Volvo FH - blanco
...
```

## Generar la documentación (Javadoc)

Todas las clases llevan comentarios **Javadoc** (`/** ... */`). Con ellos se genera una web de
documentación de la API:

```text
javadoc -encoding UTF-8 -d docs-api -sourcepath src modelo app
```

Abre `docs-api/index.html` en el navegador. Los comentarios usan estas etiquetas:

| Etiqueta | Para qué sirve |
|---|---|
| `@param nombre` | Describe un parámetro del método o constructor |
| `@return` | Describe el valor que devuelve el método |
| `@throws Excepcion` | Indica cuándo lanza la excepción |
| `{@link Clase}` | Enlace a otra clase o método |
| `{@inheritDoc}` | Reutiliza la documentación del método redefinido |

## Abrirlo en un IDE

En IntelliJ IDEA, Eclipse o VS Code abre la carpeta del proyecto y marca `src` como carpeta de
código fuente (*Sources Root*). Después ejecuta `Main`.

## Ideas para ampliarlo

1. Añadir la clase `Autobus` (100 km/h y 120 € al día) en el paquete `modelo`.
2. Hacer bidireccional la asociación entre `Conductor` y `Alquiler`. Pista: el método de registro
   puede ser de *paquete* (sin modificador) porque ambas clases están en `modelo`.
3. Añadir a `Flota` un método `vehiculoMasPotente()`.
4. Crear un paquete `servicio` con una clase que calcule la facturación total de una lista de alquileres.
