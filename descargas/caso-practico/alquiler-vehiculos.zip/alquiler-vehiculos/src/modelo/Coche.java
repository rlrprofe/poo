package modelo;

/**
 * Coche: un {@link Vehiculo} con un número de puertas.
 * <p>
 * El alquiler cuesta 40 € al día.
 */
public class Coche extends Vehiculo {

    private final int numPuertas;

    /**
     * Crea un coche.
     *
     * @param matricula  matrícula
     * @param marca      marca
     * @param modelo     modelo
     * @param color      color
     * @param potencia   potencia en CV
     * @param numPuertas número de puertas
     */
    public Coche(String matricula, String marca, String modelo, String color,
                 int potencia, int numPuertas) {
        super(matricula, marca, modelo, color, potencia);
        this.numPuertas = numPuertas;
    }

    /** @return el número de puertas */
    public int getNumPuertas() {
        return numPuertas;
    }

    /**
     * {@inheritDoc}
     * <p>
     * Tarifa del coche: 40 € por día.
     */
    @Override
    public double costeAlquiler(int dias) {
        return 40.0 * dias;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return super.toString() + " | Coche{puertas=" + numPuertas + "}";
    }
}
