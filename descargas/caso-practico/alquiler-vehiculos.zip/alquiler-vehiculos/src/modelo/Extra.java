package modelo;

/**
 * Complemento de un alquiler (GPS, silla infantil…) con un precio por día.
 * <p>
 * Es una <b>composición</b>: solo existe como parte de un {@link Alquiler}.
 */
public class Extra {

    private final String descripcion;
    private final double precioDia;

    /**
     * Crea un extra.
     *
     * @param descripcion nombre del extra
     * @param precioDia   precio por día en euros
     */
    public Extra(String descripcion, double precioDia) {
        this.descripcion = descripcion;
        this.precioDia = precioDia;
    }

    /** @return la descripción del extra */
    public String getDescripcion() {
        return descripcion;
    }

    /** @return el precio por día en euros */
    public double getPrecioDia() {
        return precioDia;
    }
}
