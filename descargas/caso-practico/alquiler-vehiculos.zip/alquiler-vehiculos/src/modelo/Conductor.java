package modelo;

/**
 * Persona que alquila vehículos.
 * <p>
 * De cada conductor interesan solo su DNI y su nombre; es una clase sencilla
 * a la que se asocian los alquileres ({@link Alquiler}).
 */
public class Conductor {

    private final String dni;
    private final String nombre;

    /**
     * Crea un conductor.
     *
     * @param dni    documento de identidad
     * @param nombre nombre del conductor
     */
    public Conductor(String dni, String nombre) {
        this.dni = dni;
        this.nombre = nombre;
    }

    /** @return el DNI */
    public String getDni() {
        return dni;
    }

    /** @return el nombre */
    public String getNombre() {
        return nombre;
    }
}
