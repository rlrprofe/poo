package modelo;

/**
 * Contrato de todo lo que la empresa puede alquilar.
 * <p>
 * Lo cumplen clases que no tienen relación de herencia entre sí, como
 * {@link Vehiculo} y {@link PlazaGaraje}: lo único que tienen en común es que
 * saben calcular cuánto cuesta alquilarlas.
 */
public interface Alquilable {

    /**
     * Calcula el coste de alquilar el elemento durante un número de días.
     *
     * @param dias número de días de alquiler
     * @return coste total en euros
     */
    double costeAlquiler(int dias);
}
