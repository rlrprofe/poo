package modelo;

/**
 * Camión: un {@link Vehiculo} con carga máxima y velocidad limitada a 90 km/h.
 * <p>
 * El alquiler cuesta 85 € al día más 50 € de seguro fijo.
 */
public class Camion extends Vehiculo {

    private final double cargaMaxima;

    /**
     * Crea un camión.
     *
     * @param matricula   matrícula
     * @param marca       marca
     * @param modelo      modelo
     * @param color       color
     * @param potencia    potencia en CV
     * @param cargaMaxima carga máxima en kg
     */
    public Camion(String matricula, String marca, String modelo, String color,
                  int potencia, double cargaMaxima) {
        super(matricula, marca, modelo, color, potencia);
        this.cargaMaxima = cargaMaxima;
    }

    /** @return la carga máxima en kg */
    public double getCargaMaxima() {
        return cargaMaxima;
    }

    /**
     * {@inheritDoc}
     *
     * @return 90 km/h: un camión es más lento que un coche
     */
    @Override
    public int getVelocidadMaxima() {
        return 90;
    }

    /**
     * {@inheritDoc}
     * <p>
     * Tarifa del camión: 85 € por día más 50 € de seguro fijo.
     */
    @Override
    public double costeAlquiler(int dias) {
        return 85.0 * dias + 50.0;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return super.toString() + " | Camion{cargaMaxima=" + cargaMaxima + " kg}";
    }
}
