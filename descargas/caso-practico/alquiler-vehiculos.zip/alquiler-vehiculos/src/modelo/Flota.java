package modelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Conjunto de vehículos de la empresa.
 * <p>
 * Es una <b>agregación</b>: los vehículos se crean fuera de la flota y siguen
 * existiendo aunque se retiren de ella.
 */
public class Flota {

    private final String nombre;
    private final List<Vehiculo> vehiculos = new ArrayList<>();

    /**
     * Crea una flota vacía.
     *
     * @param nombre nombre de la flota
     */
    public Flota(String nombre) {
        this.nombre = nombre;
    }

    /** @return el nombre de la flota */
    public String getNombre() {
        return nombre;
    }

    /**
     * Incorpora un vehículo a la flota.
     *
     * @param vehiculo vehículo ya creado
     */
    public void incorporar(Vehiculo vehiculo) {
        vehiculos.add(vehiculo);
    }

    /**
     * Retira un vehículo de la flota. El vehículo no se destruye.
     *
     * @param vehiculo vehículo que sale de la flota
     */
    public void retirar(Vehiculo vehiculo) {
        vehiculos.remove(vehiculo);
    }

    /** @return el número de vehículos de la flota */
    public int getNumVehiculos() {
        return vehiculos.size();
    }

    /**
     * Busca un vehículo por su matrícula.
     *
     * @param matricula matrícula buscada
     * @return el vehículo, o {@code null} si no está en la flota
     */
    public Vehiculo buscarPorMatricula(String matricula) {
        for (Vehiculo v : vehiculos) {
            if (v.getMatricula().equals(matricula)) {
                return v;
            }
        }
        return null;
    }

    /**
     * Calcula lo que costaría alquilar toda la flota.
     * Cada vehículo aplica su propia tarifa (polimorfismo).
     *
     * @param dias número de días
     * @return coste total en euros
     */
    public double costeTotal(int dias) {
        double total = 0;
        for (Vehiculo v : vehiculos) {
            total += v.costeAlquiler(dias);
        }
        return total;
    }

    /**
     * Devuelve los vehículos de la flota.
     *
     * @return lista de solo lectura: no se puede modificar desde fuera
     */
    public List<Vehiculo> getVehiculos() {
        return Collections.unmodifiableList(vehiculos);
    }
}
