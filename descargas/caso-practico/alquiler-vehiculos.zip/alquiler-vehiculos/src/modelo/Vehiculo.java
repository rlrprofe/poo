package modelo;

/**
 * Vehículo genérico de la empresa de alquiler.
 * <p>
 * Es una <b>clase abstracta</b>: no se pueden crear objetos {@code Vehiculo}
 * directamente, sino de sus subclases ({@link Coche}, {@link Camion}), que
 * deben implementar {@link #costeAlquiler(int)}.
 * <p>
 * Los atributos son privados (encapsulación): el estado del vehículo solo se
 * modifica a través de sus métodos, que comprueban que las operaciones tengan sentido.
 */
public abstract class Vehiculo implements Alquilable {

    /** Matrícula: identifica al vehículo y no cambia nunca. */
    private final String matricula;
    private String marca;
    private String modelo;
    private String color;
    private int potencia;
    /** Velocidad actual en km/h (0 si está parado). */
    private int velocidad;
    private boolean enMarcha;

    /**
     * Crea un vehículo parado y con velocidad 0.
     *
     * @param matricula matrícula del vehículo
     * @param marca     marca (por ejemplo, Ford)
     * @param modelo    modelo (por ejemplo, Focus)
     * @param color     color de la carrocería
     * @param potencia  potencia en CV; debe ser positiva
     * @throws IllegalArgumentException si la potencia no es positiva
     */
    public Vehiculo(String matricula, String marca, String modelo, String color, int potencia) {
        if (potencia <= 0) {
            throw new IllegalArgumentException("La potencia debe ser positiva");
        }
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.potencia = potencia;
    }

    /** Pone el motor en marcha. */
    public void ponerEnMarcha() {
        enMarcha = true;
    }

    /** Detiene el vehículo: velocidad 0 y motor apagado. */
    public void parar() {
        velocidad = 0;
        enMarcha = false;
    }

    /**
     * Aumenta la velocidad sin superar el máximo del vehículo.
     * <p>
     * El máximo lo decide cada subclase mediante {@link #getVelocidadMaxima()}
     * (polimorfismo).
     *
     * @param incremento km/h que se quieren aumentar; debe ser positivo
     * @throws IllegalArgumentException si el incremento no es positivo
     * @throws IllegalStateException    si el vehículo no está en marcha
     */
    public void acelerar(int incremento) {
        if (incremento <= 0) {
            throw new IllegalArgumentException("El incremento debe ser positivo");
        }
        if (!enMarcha) {
            throw new IllegalStateException("El vehículo está parado: hay que ponerlo en marcha");
        }
        velocidad = Math.min(velocidad + incremento, getVelocidadMaxima());
    }

    /**
     * Reduce la velocidad sin bajar de 0.
     *
     * @param decremento km/h que se quieren reducir; debe ser positivo
     * @throws IllegalArgumentException si el decremento no es positivo
     */
    public void frenar(int decremento) {
        if (decremento <= 0) {
            throw new IllegalArgumentException("El decremento debe ser positivo");
        }
        velocidad = Math.max(0, velocidad - decremento);
    }

    /**
     * Velocidad máxima del vehículo. Las subclases pueden redefinirla.
     *
     * @return velocidad máxima en km/h (180 por defecto)
     */
    public int getVelocidadMaxima() {
        return 180;
    }

    /** @return la matrícula */
    public String getMatricula() {
        return matricula;
    }

    /** @return la marca */
    public String getMarca() {
        return marca;
    }

    /** @return el modelo */
    public String getModelo() {
        return modelo;
    }

    /** @return el color actual */
    public String getColor() {
        return color;
    }

    /** @return la potencia en CV */
    public int getPotencia() {
        return potencia;
    }

    /** @return la velocidad actual en km/h */
    public int getVelocidad() {
        return velocidad;
    }

    /** @return {@code true} si el motor está en marcha */
    public boolean isEnMarcha() {
        return enMarcha;
    }

    /**
     * Cambia el color del vehículo.
     *
     * @param color nuevo color
     */
    public void pintar(String color) {
        this.color = color;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return "Vehiculo{matricula=" + matricula + ", marca=" + marca + ", modelo=" + modelo
                + ", color=" + color + ", velocidad=" + velocidad + " km/h}";
    }
}
