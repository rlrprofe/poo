package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Alquiler de un {@link Vehiculo} por parte de un {@link Conductor} durante unos días.
 * <p>
 * Relaciones:
 * <ul>
 *   <li><b>Asociación</b> con el vehículo y el conductor, que existen por sí mismos.</li>
 *   <li><b>Composición</b> con sus {@link Extra}: el alquiler los crea y no los comparte.</li>
 * </ul>
 */
public class Alquiler {

    private final Vehiculo vehiculo;
    private final Conductor conductor;
    private final int dias;
    private final List<Extra> extras = new ArrayList<>();

    /**
     * Crea un alquiler.
     *
     * @param vehiculo  vehículo alquilado
     * @param conductor conductor que lo alquila
     * @param dias      duración en días; debe ser al menos 1
     * @throws IllegalArgumentException si {@code dias} es menor que 1
     */
    public Alquiler(Vehiculo vehiculo, Conductor conductor, int dias) {
        if (dias <= 0) {
            throw new IllegalArgumentException("El alquiler debe ser de al menos un día");
        }
        this.vehiculo = vehiculo;
        this.conductor = conductor;
        this.dias = dias;
    }

    /**
     * Añade un extra al alquiler. Es el propio alquiler quien crea el objeto
     * {@link Extra} (composición).
     *
     * @param descripcion nombre del extra
     * @param precioDia   precio por día en euros
     */
    public void anadirExtra(String descripcion, double precioDia) {
        extras.add(new Extra(descripcion, precioDia));
    }

    /** @return el número de extras contratados */
    public int getNumExtras() {
        return extras.size();
    }

    /** @return el vehículo alquilado */
    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    /** @return el conductor que alquila */
    public Conductor getConductor() {
        return conductor;
    }

    /**
     * Calcula el importe total: coste del vehículo más todos los extras.
     *
     * @return total en euros
     */
    public double getTotal() {
        double total = vehiculo.costeAlquiler(dias);
        for (Extra e : extras) {
            total += e.getPrecioDia() * dias;
        }
        return total;
    }
}
