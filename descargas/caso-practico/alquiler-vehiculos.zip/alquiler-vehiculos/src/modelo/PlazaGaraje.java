package modelo;

/**
 * Plaza de garaje que la empresa también alquila.
 * <p>
 * No es un {@link Vehiculo}, pero cumple el contrato {@link Alquilable}.
 * El alquiler cuesta 5 € al día.
 */
public class PlazaGaraje implements Alquilable {

    private final String codigo;

    /**
     * Crea una plaza de garaje.
     *
     * @param codigo código que identifica la plaza (por ejemplo, P-12)
     */
    public PlazaGaraje(String codigo) {
        this.codigo = codigo;
    }

    /** @return el código de la plaza */
    public String getCodigo() {
        return codigo;
    }

    /**
     * {@inheritDoc}
     * <p>
     * Tarifa de la plaza: 5 € por día.
     */
    @Override
    public double costeAlquiler(int dias) {
        return 5.0 * dias;
    }
}
